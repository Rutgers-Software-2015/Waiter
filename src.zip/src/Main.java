import GUI.WaiterGUI;


public class Main {

	public static void main(String[] args) {

		new WaiterGUI();

	}

}


public class Waiter {

	public Waiter(){
		
		
	}
	
	public boolean View_Order_Queue(){
		
		
		return true;
	}
	
	public boolean Accept_Payment(float amount){
		
		
		return true;
	}
}
